# 💻 Aplx AI - CODE Mode User Guide

## What is CODE Mode?

**CODE Mode** is a dedicated interface in Aplx AI for intelligent code generation, debugging, and assistance using **Ollama Mistral**.

---

## 🚀 Quick Start

### Enter CODE Mode

Type in Aplx:
```
code
```

**Output:**
```
Aplx :- Entering CODE mode (Ollama Mistral). Type 'exit' or 'back' to leave.
Aplx :- Available models: mistral, llama2, neural-chat
R3nz (code):-
```

### Generate Code

Ask for code in any language:
```
R3nz (code):- python function to sort a list
```

### Exit CODE Mode

```
R3nz (code):- exit
```

---

## 📝 Examples

### Example 1: Function

**Request:**
```
R3nz (code):- javascript function to check if number is prime
```

**Response:**
```
Aplx :- Generating JavaScript code using Mistral AI...
Aplx :- [MISTRAL]
function isPrime(num) {
    if (num <= 1) return false;
    if (num <= 3) return true;
    if (num % 2 === 0 || num % 3 === 0) return false;
    
    for (let i = 5; i * i <= num; i += 6) {
        if (num % i === 0 || num % (i + 2) === 0) return false;
    }
    return true;
}

// Test
console.log(isPrime(17));  // true
console.log(isPrime(10));  // false
```

### Example 2: API Endpoint

**Request:**
```
R3nz (code):- flask route to get user profile
```

**Response:**
```
Aplx :- [MISTRAL]
from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/user/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = {
        'id': user_id,
        'name': 'John Doe',
        'email': 'john@example.com'
    }
    return jsonify(user)

if __name__ == '__main__':
    app.run(debug=True)
```

### Example 3: Data Analysis

**Request:**
```
R3nz (code):- python pandas to read csv and calculate mean
```

**Response:**
```
Aplx :- [MISTRAL]
import pandas as pd

# Read CSV file
df = pd.read_csv('data.csv')

# Calculate mean of all numeric columns
means = df.mean()
print("Mean values:")
print(means)

# For specific column
column_mean = df['column_name'].mean()
print(f"Mean of column: {column_mean}")
```

---

## 🎯 Supported Tasks

### ✅ Function/Method Generation
```
python function to calculate factorial
javascript method to reverse string
java class for user authentication
```

### ✅ API Development
```
REST API endpoint in FastAPI
GraphQL query resolver
Express.js middleware for authentication
```

### ✅ Data Processing
```
pandas script to merge two CSV files
SQL query to find top customers
regex to validate email addresses
```

### ✅ Web Development
```
HTML form with validation
CSS responsive grid layout
React component for todo list
```

### ✅ Database Operations
```
SQL script to create user table
MongoDB aggregation pipeline
PostgreSQL indexes for performance
```

### ✅ Debugging
```
why is this [code] not working
optimize this [code] for performance
explain this [code]
```

---

## 🔍 Language Detection

CODE Mode **automatically detects** the programming language from your request:

| Request Contains | Language |
|-----------------|----------|
| python, py, django, flask | Python |
| javascript, js, node, react, vue | JavaScript |
| java, spring, maven | Java |
| cpp, c++, c plus plus | C++ |
| csharp, c#, dotnet, .net | C# |
| golang, go | Go |
| rust, cargo | Rust |
| php, laravel | PHP |
| ruby, rails | Ruby |
| sql, postgresql, mysql | SQL |
| html, css, web | HTML/CSS |
| bash, shell, sh, script | Bash |

### Manual Language Specification

To override auto-detection, mention the language explicitly:

```
R3nz (code):- [in Ruby] function to read file
R3nz (code):- [using Go] concurrent task processor
```

---

## 💡 Tips & Tricks

### 1. Be Specific

**❌ Too vague:**
```
write a function
```

**✅ Specific:**
```
write a python function to validate credit card numbers
```

### 2. Provide Context

**❌ No context:**
```
create an API endpoint
```

**✅ With context:**
```
create a Flask API endpoint to create a new blog post with title and content
```

### 3. Request Details

**✅ Include details:**
```
python class for a bank account with deposit, withdraw, and balance methods
```

### 4. Use Code Snippets

**✅ If you have existing code:**
```
fix this sql query: SELECT * FROM users WHERE age > '25'
```

### 5. Ask for Patterns

**✅ Request design patterns:**
```
singleton pattern implementation in java
factory pattern in python
```

---

## 🔄 Multi-Turn Conversations

CODE Mode allows continuous conversation:

```
R3nz (code):- python function for binary search
[Mistral generates function]

R3nz (code):- add error handling
[Mistral enhances with error handling]

R3nz (code):- optimize for large datasets
[Mistral optimizes algorithm]

R3nz (code):- exit
```

---

## 📊 Code Output Format

Each generated code includes:

```
[MODEL_NAME]  ← Which model generated it (MISTRAL, LLAMA2, etc)
[Code content]
[Comments explaining key parts]
[Usage example]
```

**Example:**
```
[MISTRAL]
def fibonacci(n):
    """Calculate nth Fibonacci number"""
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Usage
print(fibonacci(10))  # Output: 55
```

---

## ⚙️ Advanced Features

### Specify Timeout

For complex code generation:
```
R3nz (code):- [timeout=180] optimize this recursive algorithm
```

### Check Available Models

```
R3nz (code):- what models are available
# Shows: mistral, llama2, neural-chat, etc
```

### Performance Optimization

Request optimization specifically:
```
R3nz (code):- optimize for performance: [code]
```

### Best Practices

Request best practices along with code:
```
R3nz (code):- python datetime handling with best practices
```

---

## 🐛 Common Tasks

### Database

```
R3nz (code):- create mongodb schema for user profile
R3nz (code):- sql query to get top 10 selling products
R3nz (code):- elasticsearch query for full-text search
```

### Web Framework

```
R3nz (code):- django model for blog posts
R3nz (code):- express middleware for rate limiting
R3nz (code):- fastapi dependency injection example
```

### Data Science

```
R3nz (code):- numpy array filtering
R3nz (code):- matplotlib pie chart
R3nz (code):- scikit-learn classification example
```

### Testing

```
R3nz (code):- pytest test for login function
R3nz (code):- jest test for react component
R3nz (code):- unittest for python class
```

---

## 🎓 Learning Path

### Beginner
1. Start with simple functions
2. Ask for explanations
3. Request full examples
4. Gradually increase complexity

### Intermediate
1. Request specific patterns
2. Ask for optimizations
3. Include existing code
4. Request error handling

### Advanced
1. Request design patterns
2. Optimize algorithms
3. Refactor code
4. Performance tuning

---

## 📋 Best Practices

1. **Clear Requests** - State what language and what task
2. **Provide Context** - Give requirements or examples
3. **Ask Questions** - Request explanations if needed
4. **Iterate** - Refine code through follow-ups
5. **Test Generated Code** - Always test before using in production
6. **Add Comments** - Request comments if code lacks explanation

---

## ⚠️ Limitations

- Generated code should be reviewed before production use
- May require minor adjustments for specific needs
- Complex algorithms may need further optimization
- Always test with your specific use cases

---

## ✅ Checklist

Before using CODE Mode:

- [ ] Ollama installed
- [ ] Mistral model downloaded (`ollama pull mistral`)
- [ ] Ollama service running (`ollama serve`)
- [ ] Aplx AI updated to V1.4+
- [ ] CODE Mode responsive to `code` command

---

## 🚀 Start Coding

**Now you can:**
```
python aplx.py
→ type: code
→ Generate intelligent code instantly!
```

**Your AI coding assistant is ready!** 💻🤖

---

*CODE Mode Guide | Aplx V1.4+ | 2026-06-22*
