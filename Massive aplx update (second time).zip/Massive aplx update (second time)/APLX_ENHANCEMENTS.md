# Aplx AI - Cross-Platform & Storage Enhancements

## Overview
**Aplx V1.4** has been enhanced with comprehensive cross-platform support and intelligent storage allocation management. The code now runs seamlessly on **Windows, macOS, Linux, and Android (via Termux)**.

---

## ✨ Key Enhancements

### 1. **Cross-Platform Compatibility** 
The application now detects and adapts to any operating system:
- ✅ **Windows** (native support)
- ✅ **macOS/Darwin** (native support)
- ✅ **Linux** (all distributions)
- ✅ **Android** (via Termux or similar environments)

### 2. **Storage Allocation System**
A new `StorageManager` class provides intelligent storage management:

```python
class StorageManager:
    - Detects platform capabilities
    - Allocates storage dynamically
    - Tracks memory usage
    - Provides fallback mechanisms
    - Manages cache, logs, and data directories
```

**Features:**
- Maximum configurable storage (default: 500MB)
- Real-time storage tracking
- Platform-specific directory structures
- Automatic fallback for low-storage scenarios

### 3. **Platform Detection**
Automatic detection includes:
- OS type (Windows/macOS/Linux/Android)
- Architecture (x86_64, ARM, ARM64, etc.)
- Android environment detection (Termux, native apps)
- Storage path optimization per platform

---

## 📊 Storage Management Details

### Storage Directory Structure

**Windows:**
```
%APPDATA%/Aplx/data/
├── cache/
├── logs/
└── data/
```

**macOS:**
```
~/Library/Application Support/Aplx/
├── cache/
├── logs/
└── data/
```

**Linux:**
```
~/.aplx_data/
├── cache/
├── logs/
└── data/
```

**Android (Termux):**
```
~/.aplx_data/
or
/data/data/com.termux/files/home/.aplx_data/
├── cache/
├── logs/
└── data/
```

### Storage API Functions

#### `StorageManager.get_available_storage() -> float`
Returns available storage in MB.

#### `StorageManager.allocate_storage(size_mb: float, purpose: str) -> bool`
Allocates storage for a specific purpose.

#### `StorageManager.free_storage(size_mb: float)`
Frees up allocated storage.

#### `StorageManager.get_storage_info() -> dict`
Returns comprehensive storage information:
```python
{
    'platform': 'Linux',
    'is_android': False,
    'storage_path': '/home/user/.aplx_data',
    'max_allocated_mb': 500,
    'used_storage_mb': 125.5,
    'available_storage_mb': 374.5
}
```

---

## 🔧 Platform-Specific Functions

### Browser Opening
The `open_default_browser()` function now supports:
- **Android:** Uses Android Intent Manager (am command)
- **Windows:** Native `os.startfile()` 
- **macOS:** Uses `open` command
- **Linux:** Uses `xdg-open` or `gio`

### File Explorer
The `open_file_explorer()` function now supports:
- **Android:** Opens file manager via Intent or shows storage path
- **Windows:** Opens Explorer
- **macOS:** Opens Finder
- **Linux:** Opens file manager via gio or xdg-open

### Terminal Clearing
The `clear_terminal_smooth()` function now supports:
- **Android:** Uses `clear` command
- **POSIX systems:** Uses `clear`
- **Windows:** Uses `cls`
- **Fallback:** Prints blank lines

---

## 🚀 New System Information Display

Updated `get_self_status()` now shows:
```
I am Aplx AI (V1.4) Build #1. 
Uptime: 1d 2h 15m. 
Interactions: 42. 
Credits: ∞ (INFINITE). 
Upgrades: 3. 
Oolama: available. 
Network: online. 
Platform: Linux (x86_64). 
Storage: 125.5MB/500MB.
```

---

## 📱 Android/Termux Specific Features

### Termux Detection
The system automatically detects and optimizes for:
- Termux terminal app
- Android environment variables
- System-level Android features

### Android PATH Additions
Extended PATH includes Android-specific directories:
```
~/.termux/bin
/data/data/com.termux/files/usr/bin
/system/bin
```

### Conservative Resource Usage
Android version uses:
- Smaller cache limits (100MB default)
- Optimized memory footprint
- Android-compatible commands

---

## 📝 Version Changes

| Component | Before | After |
|-----------|--------|-------|
| Version | V1.3 | V1.4 |
| Build | System dependent | Cross-platform aware |
| Storage | No tracking | Full allocation system |
| Platform Support | Windows/Mac/Linux | +Android (+Termux) |
| Storage Dirs | Hardcoded | Dynamic per-platform |

---

## 🛠️ Configuration

### Initialize Storage
```python
from aplx import STORAGE_MANAGER

# Get storage info
info = STORAGE_MANAGER.get_storage_info()
print(f"Available: {info['available_storage_mb']}MB")

# Allocate storage
if STORAGE_MANAGER.allocate_storage(50, "cache"):
    print("50MB allocated for cache")
```

### Check Platform
```python
from aplx import STORAGE_MANAGER, get_platform_info

# Get platform info
platform = get_platform_info()
print(f"Running on: {platform}")

# Check if Android
if STORAGE_MANAGER.platform_info['is_android']:
    print("Running on Android!")
```

---

## 🔄 Backward Compatibility

✅ **All existing code remains compatible**
- Existing functions work on all platforms
- Previous functionality preserved
- New features are additive

---

## 📦 Requirements

### Python Modules
```
psutil  - For storage/memory monitoring
platform - For system detection (built-in)
pathlib - For cross-platform paths (built-in)
```

### Optional for Android
```
- Termux app (or any Python environment)
- No special root access needed
```

---

## 🚨 Error Handling

All platform-specific operations include:
- Try-catch blocks for safety
- Fallback mechanisms
- Graceful degradation
- User-friendly error messages

---

## 📊 System Improvements

| Feature | Benefit |
|---------|---------|
| Cross-Platform | Run anywhere Python runs |
| Storage Allocation | Efficient resource usage |
| Dynamic Paths | Works on any OS |
| Android Support | Mobile development possible |
| Error Handling | Robust fallbacks |
| Platform Detection | Auto-optimization |

---

## 🎯 Usage Examples

### Example 1: Get Platform Info
```python
from aplx import STORAGE_MANAGER, get_platform_info

print(f"Platform: {get_platform_info()}")
print(f"Details: {STORAGE_MANAGER.platform_info}")
```

### Example 2: Manage Storage
```python
# Check available storage
available = STORAGE_MANAGER.get_available_storage()
print(f"Available: {available}MB")

# Allocate for cache
if STORAGE_MANAGER.allocate_storage(100, "cache"):
    print("Cache storage allocated")
else:
    print("Not enough storage")

# Free up storage
STORAGE_MANAGER.free_storage(50)
```

### Example 3: Cross-Platform Browser
```python
from aplx import open_default_browser

# Works on any platform including Android
open_default_browser("https://github.com")
```

---

## ✅ Testing Checklist

- [x] Syntax validation passed
- [x] Cross-platform imports verified
- [x] Storage manager initialized
- [x] Platform detection working
- [x] Android paths configured
- [x] Browser opening enhanced
- [x] File explorer enhanced
- [x] Terminal clearing improved
- [x] Status display updated
- [x] Error handling added

---

## 🔗 Files Modified

- **`aplx.py`** - Main application file
  - Added StorageManager class (140+ lines)
  - Added platform detection
  - Enhanced system functions
  - Updated version to V1.4

- **`aplx_backup.py`** - Backup of original
  - Preserved for reference

---

## 📞 Support

For platform-specific issues:
1. Check `STORAGE_MANAGER.platform_info` for detection
2. Review error messages in console
3. Verify storage path accessibility
4. Check file permissions

---

## 🎉 Summary

Aplx AI is now a **truly universal application** that runs seamlessly across:
- ✅ Desktop (Windows, macOS, Linux)
- ✅ Mobile (Android via Termux)
- ✅ Any Python environment

With intelligent storage management and cross-platform optimization!

---

*Last Updated: 2026-06-22*
*Version: Aplx V1.4*
