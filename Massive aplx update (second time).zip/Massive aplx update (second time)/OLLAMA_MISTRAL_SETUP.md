# 🤖 Aplx AI - Ollama Mistral Integration Guide

## Overview

Aplx AI V1.4+ now includes native **Ollama Mistral** integration with a dedicated **CODE mode** for intelligent code generation, debugging, and assistance.

---

## ⚡ Quick Setup

### 1. Install Ollama

**macOS/Linux:**
```bash
curl https://ollama.ai/install.sh | sh
```

**Windows:**
- Download from: https://ollama.ai
- Run installer

**Android (Termux):**
```bash
apt install curl
curl https://ollama.ai/install.sh | sh
```

### 2. Pull Mistral Model

```bash
ollama pull mistral
```

Other models available:
```bash
ollama pull llama2           # LLaMA 2
ollama pull neural-chat      # Neural Chat
ollama pull codellama        # Code LLaMA
```

### 3. Start Ollama Service

```bash
ollama serve
# Or run in background:
ollama serve &
```

### 4. Verify Installation

```bash
which ollama
ollama list
```

---

## 🚀 Usage in Aplx AI

### Enter CODE Mode

In Aplx AI, simply type:
```
code
```

or

```
coding
```

or

```
code mode
```

**Output:**
```
Aplx :- Entering CODE mode (Ollama Mistral). Type 'exit' or 'back' to leave.
Aplx :- Available models: mistral, llama2, neural-chat
R3nz (code):-
```

### Generate Code

**Example 1: Python function**
```
R3nz (code):- write a python function to calculate fibonacci
```

**Example 2: Web API**
```
R3nz (code):- create a REST API endpoint in FastAPI to get user data
```

**Example 3: JavaScript**
```
R3nz (code):- javascript function to validate email addresses
```

**Output:**
```
Aplx :- Generating Python code using Mistral AI...
Aplx :- [MISTRAL]
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Usage
print(fibonacci(10))  # Output: 55
```

### Exit CODE Mode

```
R3nz (code):- exit
```

---

## 🔧 Advanced Configuration

### Check Available Models

```bash
ollama list
```

**Output:**
```
NAME              ID              SIZE      MODIFIED     
mistral:latest    2f7cbf2d1b54    4.1 GB    2 minutes ago
llama2:latest     78e26419b446    3.8 GB    1 hour ago
```

### Using Different Models

Edit `/home/r3nz/Desktop/aplx.py` and modify:

```python
# Change default model for CODE mode
models_to_try = ["mistral", "llama2"]  # Line ~1945
```

### Customize Model Parameters

To use Ollama with custom parameters, modify the `oolama_code` function:

```python
# Add custom flags (in aplx.py around line 1955)
result = subprocess.run(
    [executable, "run", model, "--temperature", "0.7", code_prompt],
    # ...
)
```

### Timeout Configuration

Adjust timeout for long-running code generation:

```python
# In Aplx AI
R3nz (code):- timeout is 60
R3nz (code):- create a complex machine learning pipeline

# Or edit aplx.py:
timeout = 180  # seconds
```

---

## 📊 Supported Languages

CODE mode auto-detects and supports:

- ✅ Python
- ✅ JavaScript / TypeScript
- ✅ Java
- ✅ C++
- ✅ C#
- ✅ Go
- ✅ Rust
- ✅ PHP
- ✅ Ruby
- ✅ HTML/CSS/SQL
- ✅ Bash/Shell
- ✅ And more...

---

## 🔍 Features

### Automatic Language Detection
```
R3nz (code):- function to reverse a string
# Auto-detects: Python (or your preferred language)
```

### Code Generation
```
R3nz (code):- REST API endpoint to fetch todos
# Generates: Complete API code with error handling
```

### Code Patterns
```
R3nz (code):- design pattern for singleton
# Generates: Implementation example
```

### Debugging Help
```
R3nz (code):- why is this failing [paste code]
# Mistral analyzes and suggests fixes
```

---

## 📂 PATH Integration

Aplx automatically searches for Ollama in:

**Priority Order:**
1. `$PATH` environment variable (all directories)
2. `~/.local/bin/ollama`
3. `~/bin/ollama`
4. `/usr/local/bin/ollama`
5. `/usr/bin/ollama`
6. Android: `~/.termux/bin/ollama`
7. Android: `/data/data/com.termux/files/usr/bin/ollama`

**Verify PATH:**
```bash
echo $PATH
which ollama
```

**Add to PATH (if needed):**

**Linux/macOS:**
```bash
export PATH="$PATH:$(dirname $(which ollama))"
```

**Windows PowerShell:**
```powershell
$env:Path += ";C:\Users\YourName\AppData\Local\ollama"
```

---

## 🐛 Troubleshooting

### Issue: "Ollama is not installed"

**Solution:**
```bash
# Install Ollama
curl https://ollama.ai/install.sh | sh

# Start service
ollama serve
```

### Issue: "Model not found"

**Solution:**
```bash
# Download Mistral
ollama pull mistral

# List available
ollama list
```

### Issue: "Connection refused"

**Solution:**
```bash
# Ollama service not running
ollama serve &

# Or in another terminal:
ollama serve
```

### Issue: "Timeout"

**Solution:**
```
R3nz (code):- [try simpler request]
# Or wait for Mistral to load (first run takes longer)
```

### Issue: "Slow response"

**Optimize:**
```bash
# Ensure only Ollama running
pkill -f ollama

# Start fresh
ollama serve
```

---

## 🔌 Integration Details

### Function: `ollama_mistral(query, timeout=120)`

**Generate response using Mistral:**
```python
from aplx import ollama_mistral

response = ollama_mistral("explain recursion")
print(response)
```

### Function: `oolama_code(query, language=None, timeout=None, use_mistral=True)`

**Generate code using Mistral:**
```python
from aplx import oolama_code

code = oolama_code("async function to fetch API", language="JavaScript")
print(code)
```

### Function: `get_available_ollama_models()`

**List installed models:**
```python
from aplx import get_available_ollama_models

models = get_available_ollama_models()
print(f"Available: {models}")
```

---

## 📱 Android/Termux Setup

### Step 1: Install Ollama in Termux

```bash
apt update
apt install curl
curl https://ollama.ai/install.sh | sh
```

### Step 2: Pull Model

```bash
ollama pull mistral
```

### Step 3: Start Service

```bash
ollama serve
```

### Step 4: Use in Aplx

In another Termux session:
```bash
python aplx.py
```

Then use CODE mode as normal!

---

## ⚡ Performance Tips

### 1. RAM Management
- Mistral: 8GB+ recommended
- LLaMA 2: 8GB+ recommended
- neural-chat: 4GB+ recommended

### 2. Model Selection
```bash
# Faster (4GB RAM)
ollama pull neural-chat

# Balanced (8GB RAM)
ollama pull mistral

# Most powerful (16GB RAM)
ollama pull llama2:70b
```

### 3. System Resources
```bash
# Monitor during use
watch -n 1 'free -h && ps aux | grep ollama'
```

---

## 🔐 Security

✅ **Ollama runs locally - no data leaves your computer**

- ✅ No API keys needed
- ✅ No cloud connection required
- ✅ Private by default
- ✅ Full control over models

---

## 📚 Examples

### Example 1: Web Scraper

```
R3nz (code):- python web scraper for news headlines
```

**Result:**
```python
[MISTRAL]
import requests
from bs4 import BeautifulSoup

url = "https://news.example.com"
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')
headlines = [h.text for h in soup.find_all('h2')]
for headline in headlines:
    print(headline)
```

### Example 2: REST API

```
R3nz (code):- FastAPI endpoint to manage todos
```

**Result:**
```python
[MISTRAL]
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Todo(BaseModel):
    title: str
    completed: bool = False

todos = []

@app.get("/todos")
async def get_todos():
    return todos

@app.post("/todos")
async def create_todo(todo: Todo):
    todos.append(todo)
    return todo
```

### Example 3: Data Processing

```
R3nz (code):- python script to analyze CSV data
```

**Result:**
```python
[MISTRAL]
import pandas as pd

df = pd.read_csv('data.csv')
print(f"Total rows: {len(df)}")
print(f"Columns: {df.columns.tolist()}")
print(df.describe())
```

---

## 🎯 Best Practices

1. **Clear Requests** - Be specific about what you want
2. **Language Hints** - Mention the language explicitly
3. **Context** - Provide existing code or requirements
4. **Iterate** - Ask follow-up questions for refinement
5. **Test Code** - Always test generated code

---

## 🔗 Resources

- **Ollama Official:** https://ollama.ai
- **Mistral AI:** https://mistral.ai
- **Models Available:** https://ollama.ai/library
- **Ollama GitHub:** https://github.com/ollama/ollama

---

## 📊 Version Info

- **Aplx Version:** V1.4+
- **Ollama Support:** All versions
- **Mistral Support:** Latest
- **Last Updated:** 2026-06-22

---

## ✅ Verification Checklist

- [ ] Ollama installed and running
- [ ] Mistral model downloaded (`ollama pull mistral`)
- [ ] Ollama in PATH or auto-detected
- [ ] Aplx AI updated to V1.4+
- [ ] CODE mode works (`code` command)
- [ ] Can generate code successfully

---

## 🚀 Ready to Code!

Your Aplx AI is now powered by **Ollama Mistral** for intelligent code generation!

**Start using:**
```bash
python aplx.py
# Then type: code
```

**Happy coding! 🎉**

---

*Ollama Mistral Integration | Aplx V1.4+ | 2026-06-22*
