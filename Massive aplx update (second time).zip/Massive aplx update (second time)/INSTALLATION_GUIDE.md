# Aplx V1.4 - Installation & Setup Guide

## 🖥️ Windows Installation

### Prerequisites
- Python 3.8+
- pip (included with Python)

### Steps
1. **Download Python**
   - Visit: https://www.python.org/downloads/
   - Download latest Python 3.x
   - **Important:** Check "Add Python to PATH"

2. **Install Required Package**
   ```bash
   pip install psutil
   ```

3. **Run Aplx**
   ```bash
   python aplx.py
   ```

### Verify
```bash
python -c "import psutil; print('OK')"
```

---

## 🍎 macOS Installation

### Using Homebrew (Recommended)
```bash
# Install Homebrew if not installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Python
brew install python3

# Install psutil
pip3 install psutil

# Run Aplx
python3 aplx.py
```

### Using Python.org
1. Visit: https://www.python.org/downloads/macos/
2. Download macOS installer
3. Run installer
4. Install psutil: `pip3 install psutil`
5. Run: `python3 aplx.py`

### Verify
```bash
python3 -c "import psutil; print('OK')"
```

---

## 🐧 Linux Installation

### Ubuntu/Debian
```bash
# Update system
sudo apt update
sudo apt upgrade

# Install Python and pip
sudo apt install python3 python3-pip

# Install psutil
pip3 install psutil

# Run Aplx
python3 aplx.py
```

### Fedora/RHEL
```bash
# Install Python and pip
sudo dnf install python3 python3-pip

# Install psutil
pip3 install psutil

# Run Aplx
python3 aplx.py
```

### Arch Linux
```bash
# Install Python and pip
sudo pacman -S python python-pip

# Install psutil
pip install psutil

# Run Aplx
python aplx.py
```

### Verify
```bash
python3 -c "import psutil; print('OK')"
```

---

## 📱 Android Installation (Termux)

### Prerequisites
- Android device
- F-Droid app store OR Google Play Store

### Step-by-Step

#### 1. Install Termux
**Option A: F-Droid (Recommended)**
- Open F-Droid app store
- Search: "Termux"
- Install (latest version)

**Option B: Google Play**
- Open Play Store
- Search: "Termux"
- Install (latest version)

#### 2. Update Termux
```bash
apt update
apt upgrade -y
```

#### 3. Install Python
```bash
apt install python3 -y
```

#### 4. Install Required Package
```bash
pip install psutil
```

#### 5. Copy Aplx File
```bash
# Method 1: Using curl (if file is online)
curl -O https://your-url/aplx.py

# Method 2: Manual copy
# Copy aplx.py to Termux home directory
# Using file manager: /data/data/com.termux/files/home/
```

#### 6. Run Aplx
```bash
python aplx.py
```

### Android Permissions
- Termux will ask for storage permissions on first run
- Grant permissions for full functionality
- Browser functionality uses Android Intents (auto-works)

### Storage Location on Android
```
/data/data/com.termux/files/home/.aplx_data/
├── cache/
├── logs/
└── data/
```

### Tips for Android
- Keep Termux running in background
- Use Termux session manager for long operations
- Allocate 100MB+ of storage for optimal use

---

## 🔍 Verify Installation

### Check Python
```bash
python --version
python3 --version
```

### Check psutil
```bash
python -c "import psutil; print(psutil.virtual_memory())"
```

### Check Aplx
```bash
python aplx.py
# Should display: Aplx AI interface
```

---

## 🚨 Common Issues & Solutions

### Issue: "psutil not found"
```bash
# Solution 1: Install with pip
pip install psutil

# Solution 2: Use pip3
pip3 install psutil

# Solution 3: Linux with package manager
sudo apt install python3-psutil  # Ubuntu/Debian
```

### Issue: "Python not found"
```bash
# Windows: Check PATH in Python installer
# macOS: Use python3 instead of python
# Linux: Install python3 package
```

### Issue: Permission Denied (Linux)
```bash
# Make executable
chmod +x aplx.py

# Run with python
python3 aplx.py
```

### Issue: Android/Termux crashes
```bash
# Ensure enough storage
du -sh ~/.aplx_data

# Update Termux
apt update && apt upgrade

# Reinstall psutil
pip install --force-reinstall psutil
```

### Issue: Storage path errors
```bash
# Check accessible paths
mkdir -p ~/.aplx_data/{cache,logs,data}

# Verify permissions
ls -la ~/.aplx_data/
```

---

## 📦 Requirements Summary

| Platform | Python | psutil | Other |
|----------|--------|--------|-------|
| Windows | 3.8+ | ✓ | None |
| macOS | 3.8+ | ✓ | None |
| Linux | 3.8+ | ✓ | None |
| Android | 3.9+ | ✓ | Termux app |

---

## 🎯 Platform-Specific Features

### Windows
- Full browser/file explorer integration
- Native system calls
- Windows API support

### macOS
- macOS-specific commands (open, etc.)
- Full Finder integration
- M1/M2 native support

### Linux
- xdg-open support
- GNOME/KDE integration
- All distributions supported

### Android
- Android Intent support
- Termux environment variables
- /system/ access where available

---

## 🔧 Advanced Configuration

### Custom Storage Limit
Edit `aplx.py` and change:
```python
STORAGE_MANAGER = StorageManager(max_storage_mb=1000)  # 1GB instead of 500MB
```

### Custom Storage Path (if needed)
```python
# Before running Aplx
import os
os.environ['APLX_STORAGE_PATH'] = '/custom/path'
```

---

## 🆘 Getting Help

### Check Installation Status
```bash
# Run diagnostic
python -c "
import sys, platform
import psutil
print(f'Python: {sys.version}')
print(f'Platform: {platform.system()} {platform.machine()}')
print(f'RAM: {psutil.virtual_memory().total / (1024**3):.1f}GB')
print('✓ All dependencies installed!')
"
```

### Enable Debug Mode
```bash
APLX_DEBUG=1 python aplx.py
```

---

## ✅ Quick Start Checklist

- [ ] Python installed (version 3.8+)
- [ ] psutil installed (`pip install psutil`)
- [ ] aplx.py copied to working directory
- [ ] Run: `python aplx.py`
- [ ] Storage directories created
- [ ] No permission errors
- [ ] Interface displaying correctly

---

## 📞 Troubleshooting Flowchart

```
❌ "psutil not found"
  └─→ Run: pip install psutil

❌ "Python not found"
  └─→ Add Python to PATH or use full path

❌ Storage permission error
  └─→ Check directory permissions
  └─→ Android: Grant storage permission

❌ Browser not opening
  └─→ Check platform detection
  └─→ Android: Ensure Intent Manager available

❌ Terminal not clearing
  └─→ Fallback to newlines works
  └─→ Check console emulator support
```

---

## 🎉 You're Ready!

Once installation is complete:

1. **Run:** `python aplx.py`
2. **Enjoy:** Full AI chatbot experience
3. **Use:** On ANY platform!

---

*Installation Guide | Aplx V1.4 | 2026-06-22*
