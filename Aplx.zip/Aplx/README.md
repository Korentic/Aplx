# APLX Local AI

This repository contains a local AI assistant built around `aplx_1.5.py`## What’s included


- `aplx_1.5.py`
  - Main local assistant loop
  - Ollama integration and model switching
  - Local APLX model switch support via `/model`



## How to use

1. Place `aplx_1.5.py` in the same folder.
2. Make sure the APLX checkpoint directory exists, for example:
   - `aplx_checkpoints/best`
3. Run the assistant:
   ```bash
   python aplx_1.5.py
   ```

## Switch between Ollama and local APLX

Inside the assistant prompt, type:

- `/model` or `model`

Then choose one of:

- `aplx` or `native` or `local` — switch to the local APLX engine
- `ollama` or `server` — switch back to Ollama
- `fast` — use `llama3.2:1b`
- `smart` — use `llama3.2:3b`
- `genius` — use `llama3.1:8b`
- `code` — use `qwen2.5-coder:3b`

## Local APLX integration

When you switch to `aplx`, `aplx_1.5.py` will:

- import `aplx_test.py` helpers
- call `load_native_aplx_engine()`
- use `native_aplx_chat()` for prompt responses
- use the local APLX model path `aplx_checkpoints/best` by default

## Notes

- Ollama still handles the default chat/code path
- The local APLX engine only activates when you switch to `aplx`
- If the checkpoint path is missing, the assistant reports an error and keeps running

## Quick commands

- `/model` — choose Ollama or local APLX
- `/auto` — toggle auto model selection
- `save it`, `run code`, `improve this`, `write tests` — code work commands
- `exit`, `sleep`, `quit` — close the assistant

## Recommended folder setup

```
Desktop/
  aplx_1.5.py
  ```