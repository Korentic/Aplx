                                                                **HOW TO RUN IT?**

*steps:-*

 1. Install Termux from playstore
 2. Go to termux and allow permission to do stuff in storage.
 3. Go to google and ask it to find the location where you have stored aplx.py (WARNING, YOU *must* REMOVE THE aplx.py FROM THIS FOLDER FOR IT TO WORK!!)
 4. Copy the prompt and paste it in termux and hit enter
 5. Enjoy Aplx on android!