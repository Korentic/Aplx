                                                    !!WARNING THIS VERSION OF APLX IS VERY DIFFERENT, READ BELOW!!
                                                    
 HOW TO MAKE IT WORK?
 -> MUST HAVE OLLAMA (V3.2)
 -> Open the aplx.py file through visual studios
 -> go to visual studios and enter chat mode with the AI
 -> Ask the AI to connect Ollama PATH file to the aplx.py
 -> Lastly make it allocate storage (would be told in /help feature)
==========================================================================================================================================================

Why This version of Aplx requires Ollama?
-> This version of aplx has been trained to help assist developers in coding/debugging their codes.

Is Aplx powerful than Most Big shot companies?
-> No, Aplx is not as powerful as actual multi-billion dollar companies, its just a privacy first basic coding tool made by a teen.

==========================================================================================================================================================

Credits :- R3nz, Visual studios code Github Copilot, Gemini, Devin AI (Devin, was used to only generate the storage allocation)